/**
 * Types of roads:
 * M (Motorway)
 * B (Road)
 * U (Unclassfied)
 */
public enum RoadType {
    M, A, B, U;
}
