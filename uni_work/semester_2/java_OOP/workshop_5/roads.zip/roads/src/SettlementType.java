public enum SettlementType {
    HAMLET, VILLAGE, TOWN, CITY;
}
